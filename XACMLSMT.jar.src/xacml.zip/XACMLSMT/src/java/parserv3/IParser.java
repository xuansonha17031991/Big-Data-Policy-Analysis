package parserv3;

import objects.Policy;

public abstract interface IParser
{
  public abstract Policy parse(String paramString);
}


/* Location:              /Users/okielabackend/Downloads/XACMLSMT.jar!/parserv3/IParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */