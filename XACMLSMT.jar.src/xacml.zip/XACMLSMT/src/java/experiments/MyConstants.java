package experiments;

public class MyConstants {
	public static final String DB_NAME = "AccessControl";
	public static final String HOST = "localhost";
	public static final int PORT = 27017;
}
