package translator;

public class SimplifiedCustomizer {}


/* Location:              /Users/okielabackend/Downloads/XACMLSMT.jar!/translator/SimplifiedCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */