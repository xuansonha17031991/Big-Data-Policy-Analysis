package pn_xacm;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class amountPolicy {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		getPolicy();
	}
		public static void getPolicy() throws ParserConfigurationException, SAXException, IOException {
			int DenPolicyset=0;
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse("policies\\continue-a-xacml3.xml");
			NodeList rootNodePolicySet = doc.getElementsByTagName("PolicySet");
			NodeList rootNodePolicy = doc.getElementsByTagName("Policy");
			NodeList rootNodeRule = doc.getElementsByTagName("Rule");
			System.out.println("Total of PolicySet : " + rootNodePolicySet.getLength());
			System.out.println("Total of Policy : " + rootNodePolicy.getLength());
			System.out.println("Total of Rule : " + rootNodeRule.getLength());
/*			for (int i = 0; i < rootNodeList.getLength(); i++) {
				Node rootNode = rootNodeList.item(i);
				DenPolicyset++;
				Element rootElement = (Element) rootNode;
				if (rootNode.getNodeType() == Node.ELEMENT_NODE) {
					NodeList childNodeList = rootElement.getChildNodes();
				for (int j = 0; j < childNodeList.getLength(); j++) {
						Node childNode = childNodeList.item(j);
						if (childNode.getNodeType() == Node.ELEMENT_NODE) {
							Element childElement = (Element) childNode;
							System.out.println(childElement.getAttribute("Policy"));
							
						}

					}

				}

			}	
	}*/
}
}
