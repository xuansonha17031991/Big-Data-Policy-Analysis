package pn_xacm;

public class manager {
	  public String getReSource4() {
		return this.reSource4;
	}
	public void setReSource4(String reSource4) {
		this.reSource4 = reSource4;
	}
	public String getResouce1() {
		return this.resouce1;
	}
	public void setResouce1(String resouce1) {
		this.resouce1 = resouce1;
	}
	public String getResouce2() {
		return this.resouce2;
	}
	public void setResouce2(String resouce2) {
		this.resouce2 = resouce2;
	}
	public String getAcction3() {
		return  this.acction3;
	}
	public void setAcction3(String acction3) {
		this.acction3 = acction3;
	}
	private String resouce1;
	  private String resouce2;
	  private String acction3;
	  private String reSource4;
	  // setter - getter
}