package functions;

import objects.Expression;

public abstract class Function
  extends Expression
{
  public abstract Object evaluate();
}


/* Location:              /Users/okielabackend/Downloads/XACMLSMT.jar!/functions/Function.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */